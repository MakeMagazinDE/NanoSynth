// MIDI setup Ccommands for instrument 1 - Acoustic Grand Piano
#define CC_CMD_LIST {
176, 0, 0 // CC Bank select : Refer to sounds list. No action on drumset. GS
176, 1, 0 // CC GM Controller, Modulation
176, 2, 0 // CC 
176, 3, 0 // CC 
176, 4, 64 // CC 
176, 5, 0 // CC GM Controller, Portamento time
176, 7, 100 // CC Main Volume (default=100)
176, 8, 64 // CC Balance
176, 10, 64 // CC Pan
176, 11, 127 // CC Expression Pedal
176, 64, 0 // CC GM Controller, Damper pedal
176, 65, 0 // CC GM Controller, Portamento
176, 66, 0 // CC GM Controller, Sostenuto
176, 67, 0 // CC GM Controller, Soft pedal
176, 80, 4 // CC Reverb program
176, 81, 0 // CC Chorus program
176, 91, 0 // CC Reverb send level
176, 93, 0 // CC Chorus send level
176, 96, 0 // CC 
176, 97, 0 // CC 
176, 65, 0, 176, 64, 0, 176, 6, 2,  // RPN Pitch bend sensitivity in semitones
176, 65, 0, 176, 64, 1, 176, 6, 64,  // RPN Fine tuning in cents
176, 65, 0, 176, 64, 2, 176, 6, 64,  // RPN Coarse tuning in half-tones
176, 63, 2, 176, 62, 8, 176, 6, 64,  // NRPN Vibrate rate modify
176, 63, 2, 176, 62, 9, 176, 6, 64,  // NRPN Vibrate depth modify
176, 63, 2, 176, 62, 10, 176, 6, 64,  // NRPN Vibrate delay modify 
176, 63, 2, 176, 62, 32, 176, 6, 64,  // NRPN TVF cutoff freq modify
176, 63, 2, 176, 62, 33, 176, 6, 64,  // NRPN TVF resonance modify
176, 63, 2, 176, 62, 99, 176, 6, 64,  // NRPN Env. attack time modify
176, 63, 2, 176, 62, 100, 176, 6, 64,  // NRPN Env. decay time modify
176, 63, 2, 176, 62, 101, 176, 6, 64,  // NRPN Env. release time modify
